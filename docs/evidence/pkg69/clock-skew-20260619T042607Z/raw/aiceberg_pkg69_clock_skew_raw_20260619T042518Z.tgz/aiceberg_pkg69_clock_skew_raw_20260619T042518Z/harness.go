package main

import (
    "context"
    "encoding/binary"
    "encoding/json"
    "fmt"
    "io"
    "log"
    "net"
    "net/http"
    "os"
    "os/exec"
    "path/filepath"
    "strings"
    "sync"
    "time"
)

const ntpEpochOffset = 2208988800

func main() {
    out := "/work/result"
    _ = os.MkdirAll(out, 0755)
    ctx, cancel := context.WithTimeout(context.Background(), 75*time.Second)
    defer cancel()

    var mu sync.Mutex
    ingests := map[string]int{}
    bodies := map[string][][]byte{}

    go fakeNTP(ctx, time.Duration(envInt("OFFSET_SECONDS", 180))*time.Second)
    srv := &http.Server{Addr: "127.0.0.1:18080"}
    mux := http.NewServeMux()
    mux.HandleFunc("/__stats", func(w http.ResponseWriter, r *http.Request) {
        mu.Lock(); defer mu.Unlock()
        _ = json.NewEncoder(w).Encode(map[string]any{"ingested": ingests})
    })
    mux.HandleFunc("/v1/agent/bootstrap", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusOK) })
    mux.HandleFunc("/v1/agent/config", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusNoContent) })
    mux.HandleFunc("/v1/agent/channel", func(w http.ResponseWriter, r *http.Request) { http.Error(w, "channel off", http.StatusServiceUnavailable) })
    mux.HandleFunc("/v1/agent/ping", func(w http.ResponseWriter, r *http.Request) {
        if r.Method == http.MethodGet { _ = json.NewEncoder(w).Encode(map[string]string{"challenge":"clock"}); return }
        w.WriteHeader(http.StatusOK)
    })
    mux.HandleFunc("/v1/agent/error-report", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusAccepted) })
    mux.HandleFunc("/v1/ingest/", func(w http.ResponseWriter, r *http.Request) {
        body, _ := io.ReadAll(io.LimitReader(r.Body, 20<<20)); _ = r.Body.Close()
        mu.Lock(); ingests[r.URL.Path]++; bodies[r.URL.Path] = append(bodies[r.URL.Path], body); idx := ingests[r.URL.Path]; mu.Unlock()
        safe := strings.ReplaceAll(r.URL.Path, "/", "_")
        _ = os.WriteFile(filepath.Join(out, fmt.Sprintf("body_%s_%02d.json", safe, idx)), body, 0644)
        w.WriteHeader(http.StatusAccepted)
    })
    srv.Handler = mux
    go func(){ _ = srv.ListenAndServe() }()

    cmd := exec.CommandContext(ctx, "/usr/local/bin/aiceberg_agent")
    cmd.Env = append(os.Environ(),
        "API_BASE_URL=http://127.0.0.1:18080",
        "AGENT_TOKEN=REDACTED_CLOCK_TOKEN",
        "AGENT_CLIENT_ID=1",
        "AGENT_ID=6901",
        "HEALTH_PORT=18081",
        "LOG_LEVEL=info",
        "PING_INTERVAL=5",
        "CONFIG_SYNC_INTERVAL=10",
        "OUTBOX_FLUSH_INTERVAL=5",
        "METRICS_INTERVAL=5",
        "AGENT_TOKEN_PATH=/tmp/agent.token",
        "AGENT_STATE_PATH=/tmp/bootstrap.ok",
        "PREFS_PATH=/tmp/prefs.json",
        "OUTBOX_PATH=/tmp/outbox.db",
        "AGENTLESS_ENABLED=false",
    )
    logFile, _ := os.Create(filepath.Join(out, "agent.log"))
    defer logFile.Close()
    cmd.Stdout = logFile
    cmd.Stderr = logFile
    if err := cmd.Start(); err != nil { log.Fatal(err) }
    defer func(){ _ = cmd.Process.Kill(); _ = cmd.Wait() }()

    deadline := time.Now().Add(60*time.Second)
    var found map[string]any
    for time.Now().Before(deadline) {
        mu.Lock()
        chunks := append([][]byte(nil), bodies["/v1/ingest/metrics"]...)
        mu.Unlock()
        for _, b := range chunks {
            if ts := findTimeSync(b); ts != nil {
                found = ts
                break
            }
        }
        if found != nil { break }
        time.Sleep(1*time.Second)
    }
    summary := map[string]any{"found_time_sync": found != nil, "time_sync": found, "ingested": ingests}
    if found != nil {
        if off, ok := number(found["offset_ms"]); ok { summary["offset_ms"] = off }
        if st, ok := found["status"].(string); ok { summary["status"] = st }
    }
    b, _ := json.MarshalIndent(summary, "", "  ")
    _ = os.WriteFile(filepath.Join(out, "summary.json"), b, 0644)
    if found == nil { os.Exit(2) }
}

func fakeNTP(ctx context.Context, offset time.Duration) {
    addr, err := net.ResolveUDPAddr("udp", "127.0.0.1:123")
    if err != nil { log.Fatal(err) }
    conn, err := net.ListenUDP("udp", addr)
    if err != nil { log.Fatal(err) }
    defer conn.Close()
    _ = conn.SetReadDeadline(time.Now().Add(250*time.Millisecond))
    buf := make([]byte, 48)
    for {
        select { case <-ctx.Done(): return; default: }
        n, peer, err := conn.ReadFromUDP(buf)
        if err != nil { _ = conn.SetReadDeadline(time.Now().Add(250*time.Millisecond)); continue }
        if n < 48 { continue }
        resp := make([]byte, 48)
        resp[0] = 0x24
        resp[1] = 1
        copy(resp[24:32], buf[40:48])
        writeNTPTime(resp[32:40], time.Now().Add(offset))
        writeNTPTime(resp[40:48], time.Now().Add(offset))
        _, _ = conn.WriteToUDP(resp, peer)
    }
}

func writeNTPTime(dst []byte, t time.Time) {
    sec := uint64(t.Unix() + ntpEpochOffset)
    frac := uint64(uint32((uint64(t.Nanosecond()) << 32) / 1e9))
    binary.BigEndian.PutUint32(dst[0:4], uint32(sec))
    binary.BigEndian.PutUint32(dst[4:8], uint32(frac))
}

func findTimeSync(b []byte) map[string]any {
    var v any
    if json.Unmarshal(b, &v) != nil { return nil }
    return walk(v)
}
func walk(v any) map[string]any {
    switch x := v.(type) {
    case map[string]any:
        if ts, ok := x["time_sync"].(map[string]any); ok { return ts }
        for _, vv := range x { if r := walk(vv); r != nil { return r } }
    case []any:
        for _, vv := range x { if r := walk(vv); r != nil { return r } }
    }
    return nil
}
func number(v any) (float64, bool) { f, ok := v.(float64); return f, ok }
func envInt(key string, def int) int { raw := strings.TrimSpace(os.Getenv(key)); if raw == "" { return def }; var n int; if _, err := fmt.Sscanf(raw, "%d", &n); err != nil { return def }; return n }
